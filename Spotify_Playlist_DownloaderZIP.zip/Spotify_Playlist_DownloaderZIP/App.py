# import modules
from tkinter import *
import os
import downloader

def download():  # what happens when pressing download button
    Label(app, text="Loading...").grid(row=8, column=1, sticky=W, padx=10, pady=10)  # loading label

    pos = 0
    for item in names_list.curselection():  # gets position of item selected
        pos = item

    directory = os.getcwd()  # gets current directory
    song_directory = directory + "\Songs"
    link = downloader.find_link(position=pos)  # calls function from other file to find playlist link
    command = "python -m spotdl -o " + song_directory + " " + link  # actual bit to download song using spotdl


    os.system(command)  # call it in command prompt
    print("DONE")


app = Tk()  # create interface

# label
name_label = Label(app, text="Playlists")
name_label.grid(row=1, column=0, sticky=W, padx=10)

# listbox
names_list = Listbox(app, height=20, width=30, border=0)
names_list.grid(row=2, column=0, columnspan=5, rowspan=6, padx=10, sticky=W)

# button
download_btn = Button(app, text="Download", command=download)
download_btn.grid(row=8, column=0, sticky=W, padx=10, pady=10)
download_btn.bind_all("<Return>", download)  # runs download function when clicked

# names in listbox
playlists = downloader.playlists
for i in range(len(playlists)):
    names_list.insert(0, playlists[len(playlists) - i - 1])  # puts playlist names in the right order instead of upside down

app.title("Spotify Playlist Downloader")
app.mainloop()
