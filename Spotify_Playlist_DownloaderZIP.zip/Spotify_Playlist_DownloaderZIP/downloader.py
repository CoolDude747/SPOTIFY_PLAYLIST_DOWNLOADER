# import modules
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.action_chains import ActionChains
from time import sleep
import clipboard

login_file = open("Login_details.txt", "r")  # open text file with login details
login_content = login_file.read()  # reads it
if login_content == "":  # checks if file has content
    print('ERROR 1: You need to write your login_details in "Login_details" file')
split_content = login_content.split("\n")  # splits into list
email = split_content[0]  # first item in list
password = split_content[1]  # second item in list
login_file.close()

delay_file = open("DELAY.txt", "r")
delay = int(delay_file.read())
delay_file.close()

# download driver
installed_driver = ChromeDriverManager().install()

# make invisible
options = webdriver.ChromeOptions()
#options.headless = True

driver = webdriver.Chrome(installed_driver, options=options)
driver.get("https://open.spotify.com")  # opens website

driver.maximize_window()
sleep(delay)
driver.find_element_by_xpath('//*[@id="onetrust-accept-btn-handler"]').click()  # accept cookies

driver.find_element_by_xpath('//*[@id="main"]/div/div[2]/div[1]/header/div[4]/button[2]').click()  # log in button
sleep(delay)

driver.find_element_by_xpath('//*[@id="login-username"]').send_keys(email)  # enter email
driver.find_element_by_xpath('//*[@id="login-password"]').send_keys(password)  # enter password
driver.find_element_by_xpath('//*[@id="login-button"]').click()  # click log in
sleep(delay+5)
driver.find_element_by_xpath('//*[@id="main"]/div/div[2]/nav/div[1]/ul/li[3]/div/a').click()  # click "Your Library"
sleep(delay)
current_playlist = 3  # starts at 3 to skip liked Songs and Your Episodes
playlists = []


def find_link(position):
    playlist_link = ""
    playlist_link_check = playlist_link.split("playlist")[0]
    while playlist_link_check != "https://open.spotify.com/":
        # right click playlist to open menu
        ActionChains(driver).context_click(driver.find_element_by_xpath('//*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[' + str(position + 1 + 2) + ']/div/div[2]/a')).perform()
        sleep(delay)
        driver.find_element_by_xpath('//button[normalize-space()="Share"]').click()  # click share in mini menu
        sleep(0.2)
        driver.find_element_by_xpath('//button[normalize-space()="Copy link to playlist"]').click()  # copies link
        sleep(0.2)
        playlist_link = clipboard.paste()  # assigns copied link to variable
        playlist_link_check = playlist_link.split("playlist")[0]  # check it copied properly by splitting link and check if it starts with "https://open.spotify.com"
    return playlist_link


try:
    while True:
        # get playlist names
        playlist_name = driver.find_element_by_xpath('//*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[' + str(current_playlist) + ']').text
        split_song = playlist_name.split("\n")  # playlist_name has more than just the name so it splits it
        playlists.append(split_song[0])  # only adds first section to list
        sleep(0.2)
        current_playlist += 1

except:  # an error will eventually come up as the program won't be able find next playlist
    pass

# NOTES
# playlists
# //*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[1]
# //*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[2]
# //*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[3]

# playlists right click
# //*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[2]/div/div[2]/a
# //*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[5]/div/div[2]/a
# //*[@id="main"]/div/div[2]/div[3]/main/div[2]/div[2]/div/div/div[2]/section/div[2]/div/div[2]/div/div[6]/div/div[2]/a
